package com.Ankitha.ecom_proj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomProjApplicationTests {

	@Test
	void contextLoads() {
	}

}
